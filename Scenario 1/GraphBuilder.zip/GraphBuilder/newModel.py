import matplotlib.pyplot as plt
import numpy as np
from diagrams import Cluster, Diagram
from diagrams.custom import Custom

diagram_attr = {
    "fontsize": "32",
    "fontname": "Sans serif",
}
node_attr = {
    "fontname": "Sans-Serif",
    "fontsize": "24",
}

flowMatrix = [   
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
    [0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
    [0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
    [0, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
    [0, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
    [0, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
    [0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
    [0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
    [0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
    [0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
    [0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
    [0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
    [0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0], 
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], 
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
]

susceptible = ["S"]
exposed = ["E1", "E2", "E3", "E4", "E5"]
infected = ["I_PRE1", "I_PRE2", "I_PRE3", "I_PRE4", "I_PRE5", "I_SYMPS1", "I_SYMPS2", "I_SYMPS3", "I_SYMPM1", "I_SYMPM2" , "I_ASYMP1", "I_ASYMP2"]
hospitalized = ["HOSP_M1", "HOPS_M2", "HOSP_M3", "HOPS_S1", "HOPS_S2"]
recovered = ["R"]

nbTotalBoxes = 1 + len(exposed) + len(infected) + len(hospitalized) + len(recovered)

with Diagram("S-I-R Model Diagram", graph_attr=diagram_attr, node_attr=node_attr, show=False, filename="new_model_diagram", direction="LR"):
    boxes = {}
    number = 0
    for idx, _ in enumerate(susceptible, start=number):
        boxes[idx]= Custom("Susceptible", "./my_resources/s_box.png")
        number = number+1
    for idx, _ in enumerate(exposed, start=number):
        boxes[idx]= Custom(("Exposed"), "./my_resources/e_box.png")
        number = number+1
    for idx, _ in enumerate(infected, start=number):
        boxes[idx]= Custom(("Infected"), "./my_resources/i_box.png")
        number = number+1
    for idx, _ in enumerate(hospitalized, start=number):
        boxes[idx]= Custom(("Hospitalized"), "./my_resources/h_box.png")
        number = number+1
    for idx, _ in enumerate(recovered, start=number):
        boxes[idx] = Custom(("Recovered"), "./my_resources/r_box.png")
        number = number+1


    for i in range(len(flowMatrix)):
        for j in range(len(flowMatrix[i])): 
            if (flowMatrix[i][j] == 1): 
                boxes.get(j) >> boxes.get(i)

        