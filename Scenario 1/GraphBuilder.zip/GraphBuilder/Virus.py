class Virus: 
    def __init__(self, infectionRate=0, recoveryRate=0, numberInitInfected=0, apparitionPeriod=[], apparitionRate=0):
        self.infectionRate = infectionRate
        self.recoveryRate = recoveryRate
        self.numberInitInfected = numberInitInfected
        self.apparitionPeriod = apparitionPeriod
        self.apparitionRate = apparitionRate
      
