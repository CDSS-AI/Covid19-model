class PopulationGroup: 
    def __init__(self, contactMatrix, mobilityFactor):
       self.contactMatrix = contactMatrix
       self.mobilityFactor = mobilityFactor
